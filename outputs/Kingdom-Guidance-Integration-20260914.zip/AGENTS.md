# Kingdom repository instructions

## 项目与规则来源

- Unity 版本以 `ProjectSettings/ProjectVersion.txt` 为准（2022.3.62f3c1）；主场景 `Assets/Scenes/SampleScene.unity`，目标 Huawei P40 Pro 横屏。
- 当前源码/资产决定实现事实；本文件及就近 scoped AGENTS 规定硬约束。细化流程按下表加载，历史审计和缓存不能覆盖当前事实。
- 规范技能位于 `.agents/skills/`，可执行辅助工具位于 `tools/codex/`；`.codex/` 保存续接入口、交接和可恢复归档。
- `.workbuddy-ai/skills/kingdom-project-dev/SKILL.md` 仅为客户端适配入口。文件存在不等于自动注册/触发已验证；没有可调用入口时直接读取规范技能，不声称已激活。

## 唯一工作入口

所有仓库任务先读本文件，再进入 `.agents/skills/kingdom-project-dev/SKILL.md` 的“按任务读取”表。该表是唯一任务路由；只加载本轮相关领域，不默认通读所有技能、架构、审计和历史交接。

本文件维护全局硬约束，就近 scoped AGENTS 只补充目录约束；详细规则归属见主技能 `references/guidance-maintenance.md`。README、客户端适配、旧规则文档和经济prompt只作指针，不维护第二套路由或正文。已读入口不反复加载；直接命中领域技能时，先经过主入口完成范围检查，再返回该领域。不得另建重复经济技能。

## 不可退化的约束

- 禁止在新增代码和测试中使用反射，包括 `System.Reflection`、`BindingFlags`、反射式运行时 `Invoke`、`Activator`；使用公开强类型API或DTO，不照抄历史反射测试。
- 保留 Runtime State 的唯一可变权威：Manager校验并修改State，UI只绑定和发命令；不重做BigNumber、Pair、State/Manager/UI拆分或稳定ID迁移。
- 保留 `.meta`、GUID、稳定ID和序列化兼容，优先Editor迁移；任何授权字段外的变化必须另行确认。
- Food是唯一可封顶库存。普通资源不得增加容量、MaxAmount、仓储或隐藏截断；不恢复workforce。合法的建筑数量限制不等于资源库存容量。
- 建造/拆除/研究/工坊交易先全量校验再提交，失败不得部分修改；研究全额支付后才推进。库存不得为负，满足率按tick实际可用量计算。
- 建筑成本使用几何增长，批量购买使用闭式ExpantaNum扩展；不把UI/玩法便捷API塞入数学层，不提前引入不合时代内容的极端记数法。
- 固定UI必须创作于Scene/Prefab；运行时只绑定数据、状态和事件，不硬造固定层级、尺寸或文案。仅数据驱动重复内容与已记录的必要兼容回退例外；完整交互门槛见UI技能。
- 数值断言默认使用关系、范围或容差。仅离散计数、协议常量、稳定ID、枚举/版本或存档兼容字段等语义上要求精确时可精确比较，并说明原因；计算值不为方便而写死相等。

## 当前开发方向与验证底线

优先修复可复现玩法问题，保持已有Industrial主线静态闭合，完成当前时代生产/研究/工坊闭环；对应行为在Unity正确后再调整节奏。基础系统已存在，不根据旧Kingdom3/4/5审计重建。

- 内容/经济定义修改前运行静态闭包和离线确定性诊断，修改后重跑，并完成定义/source-sink/可达性检查、Unity编译、EditMode、相关非零PlayMode和Console；详细顺序与设计门槛见经济技能。
- 模拟器只作确定性回归。禁止扩展策略搜索、路线评分、自动决策或自动调参；不得把fixture自测/离线报告说成真实Unity或节奏验收。
- 编译失败、相关parity失败或主线不可达时，不进入下一内容里程碑、不盲调资产。纯技能/文档整理不需强行运行Unity。
- 当前证据入口：`data/content-closure-static.md`、存在时的 `data/economy-parity/`、`TestResults/Latest-Test-Errors.txt`；核对时间、输入版本和实际日志，而非只看文件名。
- 旧日期XML、pacing、基线、历史快照和 `.codex/archive/` 只作背景。不要在长期规则里固定“当前通过数/零用例/失败列表”。零项目测试、跳过关键行为或无对应日志不能验收。
- 未执行真实Unity编译时明确写：`未执行真实 Unity 编译。`

## 工作树、交接与安全

1. 修改前读当前同主题 `.codex/handoffs/`，检查 `git status`，区分并保留用户与并行任务变更。
2. 每个实施任务续写原交接：文件/行为变更、字段前后值、验证命令与结果、未解决风险、下一具体动作。新主题才建新交接；纯只读任务只回复，除非明确获准落盘。
3. 未经授权不安装包、不升级Unity、不发布、不操作用户真实存档、不终止用户Editor；不自动commit/push/创建PR，不rebase/amend/force，不丢弃工作树。
4. 生成证据保持有界；旧输出先可恢复归档后退出活动目录，不例行永久删除。测试fixture不得留在outputs或正式技能发现目录；清理必须验证实际目录已移除，失败立即报告。
